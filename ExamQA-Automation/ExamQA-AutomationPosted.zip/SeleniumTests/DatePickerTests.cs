﻿namespace SeleniumTests
{
    using FluentAssertions;
    using NUnit.Framework;
    using OpenQA.Selenium;
    using OpenQA.Selenium.Chrome;
    using OpenQA.Selenium.Interactions;
    using SeleniumTests.Pages;
    using System;
    using System.IO;
    using System.Reflection;
    using System.Threading;

    [TestFixture]
    public class DatePickerTests : BaseTest
    {
        private Actions _action;
        private DatePickerPage DatePickerPage;

        [SetUp]
        public void SetUp()
        {
            _driver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            _action = new Actions(_driver);
            _driver.Manage().Window.Maximize();
            _driver.Navigate().GoToUrl("http://demoqa.com/");
        }

        [Test]
        public void Textbox_Value_Should_Match_Secected_Date()
        {
            //Arrange
            var datePickerPage = new DatePickerPage(_driver);

            datePickerPage.DatePickerLink.Click();
            DelayForVideo();

            _action.MoveToElement(datePickerPage.DatePicker).Perform();
            DelayForVideo();

            //Act
        }
    }
}





