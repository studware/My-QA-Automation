﻿namespace SeleniumTests.Pages
{
	using OpenQA.Selenium;
    using OpenQA.Selenium.Interactions;
    using System.Threading;

    public partial class DatePickerPage : BasePage
    {
        private Actions _action;

        public DatePickerPage(IWebDriver driver) : base(driver)
	    {
	    }

        public void PickDate(IWebElement datePicker, int monthOffset, int dayTenths, int dayOnes)
        {
            Actions action = new Actions(Driver);

            action.MoveToElement(datePicker);
            Thread.Sleep(1000);

            datePicker.Click();
            Thread.Sleep(1000);

            action.MoveToElement(Month);
            Thread.Sleep(1000);

            Month.Click();
            Thread.Sleep(1000);
        }
    }
}

