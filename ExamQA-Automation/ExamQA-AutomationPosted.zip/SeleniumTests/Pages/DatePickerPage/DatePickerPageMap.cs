﻿namespace SeleniumTests.Pages
{
    using OpenQA.Selenium;

    public partial class DatePickerPage
    {
        public IWebElement DatePickerLink => Driver.FindElement(By.XPath(@"//*[@id='sidebar']/aside[2]/ul/li[9]/a"));

        public IWebElement DatePicker => Driver.FindElement(By.Id("datepicker"));

        public IWebElement Month => Driver.FindElement(By.ClassName("ui-datepicker-month"));

        public IWebElement PreviousMonth => Driver.FindElement(By.XPath(@"//*[@id='ui-datepicker-div']/div/a[1]"));

        public IWebElement NextMonth => Driver.FindElement(By.ClassName(@"//*[@id='ui-datepicker-div']/div/a[2]"));

        public IWebElement DayTenths => Driver.FindElement(By.XPath(@"//*[@id='ui-datepicker-div']/table/tbody/tr[2]/td[1]/a"));

        public IWebElement DayOne => Driver.FindElement(By.ClassName(@"//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[7]/a"));
    }
}

