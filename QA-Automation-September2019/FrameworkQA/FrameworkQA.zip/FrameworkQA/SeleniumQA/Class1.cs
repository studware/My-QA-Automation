﻿using System;

namespace SeleniumQA
{
    public class Class1
    {
    }
}
